This version of the Azure IoT MPP Capstone Library includes the code
necessary to enable learners to build Azure DevKit solutions for the
Azure IoT MPP Capstone.
